<script setup>
import Edit from '../components/edit.vue'
</script>

<template>
  <main>
    <Edit />
  </main>
</template>