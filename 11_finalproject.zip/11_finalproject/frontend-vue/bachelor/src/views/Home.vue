<script setup>
import Bachelor from '../components/bachelor.vue'
</script>

<template>
  <main>
    <Bachelor />
  </main>
</template>