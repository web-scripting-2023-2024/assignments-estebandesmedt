<script setup>
import Add from '../components/add.vue'
</script>

<template>
  <main>
    <Add />
  </main>
</template>