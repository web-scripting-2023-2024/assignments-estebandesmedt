<script setup>
import Welcome from '../components/admin.vue'
</script>

<template>
  <main>
    <Welcome />
  </main>
</template>