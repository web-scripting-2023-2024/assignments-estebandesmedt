<template>
    <div class="container">
        <div class="row">
            <div class="col-md-2">
            </div>
            <div class="col-md-8">
                <h1>PAGE NOT FOUND</h1>
                <p>Sorry the page you are looking for was not found!</p>
            </div>
        </div>
    </div>
</template>